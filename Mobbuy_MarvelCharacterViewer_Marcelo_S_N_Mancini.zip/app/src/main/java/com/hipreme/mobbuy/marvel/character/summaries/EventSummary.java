package com.hipreme.mobbuy.marvel.character.summaries;

import org.json.JSONObject;

public class EventSummary extends MarvelSummary
{
    public EventSummary(JSONObject o){super(o);}
}
