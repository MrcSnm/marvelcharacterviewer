package com.hipreme.mobbuy.marvel.character.summaries;

import org.json.JSONObject;

public class ComicSummary extends MarvelSummary
{
    public ComicSummary(JSONObject item){super(item);}

}
