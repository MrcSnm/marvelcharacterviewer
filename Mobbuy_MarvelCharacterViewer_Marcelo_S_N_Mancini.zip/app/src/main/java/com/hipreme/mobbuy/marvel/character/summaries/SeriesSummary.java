package com.hipreme.mobbuy.marvel.character.summaries;

import org.json.JSONObject;

public class SeriesSummary extends MarvelSummary
{
    public SeriesSummary(JSONObject o)
    {
        super(o);
    }
}
