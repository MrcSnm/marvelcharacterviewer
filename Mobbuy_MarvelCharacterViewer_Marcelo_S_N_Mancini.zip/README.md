# Marvel Character Viewer

This is a sample application for Marvel API loading.

Project made for Mobbuy challenge by Marcelo S N Mancini.

